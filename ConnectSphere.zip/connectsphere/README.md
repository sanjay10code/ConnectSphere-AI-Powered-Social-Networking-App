# 🌐 ConnectSphere — AI-Powered Social Networking App

> Full-stack social networking app with AI-powered feed recommendations, real-time messaging, post sharing, and follow system. Built with Node.js, Express, MongoDB, Socket.IO, and React Native-style frontend.

![Node.js](https://img.shields.io/badge/Node.js-Backend-085041?style=for-the-badge&logo=nodedotjs&logoColor=white)
![MongoDB](https://img.shields.io/badge/MongoDB-Database-3C3489?style=for-the-badge&logo=mongodb&logoColor=white)
![Socket.IO](https://img.shields.io/badge/Socket.IO-LiveChat-633806?style=for-the-badge)
![AI](https://img.shields.io/badge/AI-Feed_Recommendations-378ADD?style=for-the-badge)

---

## ✨ Features

- **User auth** — JWT-based register/login with bcrypt password hashing
- **Posts** — create, like, comment, share with image/video support
- **AI feed** — collaborative filtering + interest-based recommendation engine
- **Follow system** — follow/unfollow users, follower/following lists
- **Live chat** — real-time messaging with Socket.IO, typing indicators
- **Stories** — story feed at top of home screen
- **Search** — find users by name or username
- **Notifications** — likes, comments, follows, AI recommendations
- **Profile** — avatar, bio, cover image, post grid, stats
- **Push notifications** — FCM token support

---

## 🏗️ Architecture

```
Frontend (React Native / Web)
        │
        ▼ REST API + Socket.IO
Express.js Backend (Node.js)
        │
        ├── MongoDB (users, posts, messages)
        ├── JWT Authentication
        ├── Socket.IO (live chat, typing, likes)
        └── AI Feed Engine (collaborative filtering)
```

---

## 🚀 How to Run

### 1. Clone the repo
```bash
git clone https://github.com/sanjay10code/ConnectSphere
cd ConnectSphere/connectsphere
```

### 2. Fix PowerShell policy (Windows only)
```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

### 3. Start the backend
```bash
cd backend
npm install
node server.js
```
You should see:
```
[Server] ConnectSphere running on port 3001
```

### 4. Open the frontend
Go to `frontend/` and double-click `index.html`

Works in **demo mode** without MongoDB — uses simulated data.

---

## 📁 Project Structure

```
connectsphere/
├── backend/
│   ├── server.js               # Express + Socket.IO server
│   ├── models/
│   │   ├── User.js             # User schema with bcrypt
│   │   ├── Post.js             # Post with likes, comments
│   │   └── Message.js          # Chat messages
│   ├── routes/
│   │   ├── auth.js             # Register / Login
│   │   ├── users.js            # Profile, follow, search
│   │   ├── posts.js            # CRUD, like, comment
│   │   ├── messages.js         # Chat history
│   │   └── feed.js             # AI recommendation engine
│   ├── middleware/
│   │   └── auth.js             # JWT middleware
│   └── package.json
├── frontend/
│   └── index.html              # Full mobile-style UI
└── README.md
```

---

## 🤖 AI Feed Algorithm

Scores each post based on:

| Signal | Weight |
|--------|--------|
| Followed user's post | +100 |
| Tag matches user interests | +30 per tag |
| Like count | +2 per like (max 50) |
| Comment count | +3 per comment (max 30) |
| View count | +0.1 per view (max 20) |
| Post age | -0.5 per hour (max -40) |

---

## 🛠️ Tech Stack

![JavaScript](https://img.shields.io/badge/JavaScript-0C447C?style=for-the-badge&logo=javascript&logoColor=white)
![Node.js](https://img.shields.io/badge/Node.js-085041?style=for-the-badge&logo=nodedotjs&logoColor=white)
![Express](https://img.shields.io/badge/Express.js-085041?style=for-the-badge&logo=express&logoColor=white)
![MongoDB](https://img.shields.io/badge/MongoDB-3C3489?style=for-the-badge&logo=mongodb&logoColor=white)
![Socket.io](https://img.shields.io/badge/Socket.io-633806?style=for-the-badge&logo=socketdotio&logoColor=white)
![JWT](https://img.shields.io/badge/JWT-Auth-633806?style=for-the-badge)
