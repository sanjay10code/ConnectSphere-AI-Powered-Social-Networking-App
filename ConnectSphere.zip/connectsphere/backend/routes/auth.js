const router = require('express').Router();
const User = require('../models/User');
const { generateToken } = require('../middleware/auth');

// Register
router.post('/register', async (req, res) => {
  try {
    const { username, email, password, displayName } = req.body;
    if (!username || !email || !password) return res.status(400).json({ error: 'All fields required' });
    const exists = await User.findOne({ $or: [{ email }, { username }] });
    if (exists) return res.status(400).json({ error: 'Username or email already taken' });
    const user = await User.create({ username, email, password, displayName: displayName || username });
    const token = generateToken(user._id);
    res.status(201).json({ token, user: user.toPublic() });
  } catch(e) {
    res.status(500).json({ error: e.message });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !await user.comparePassword(password))
      return res.status(400).json({ error: 'Invalid credentials' });
    const token = generateToken(user._id);
    res.json({ token, user: user.toPublic() });
  } catch(e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
