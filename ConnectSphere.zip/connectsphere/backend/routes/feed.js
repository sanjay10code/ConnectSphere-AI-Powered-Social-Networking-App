const router = require('express').Router();
const Post = require('../models/Post');
const User = require('../models/User');
const { auth } = require('../middleware/auth');

// AI recommendation engine — collaborative filtering + interest matching
async function getRecommendedFeed(userId, userInterests, following, page = 1) {
  const limit = 20;
  const skip = (page - 1) * limit;

  // Weight scores: following posts > interest-matched > trending > random
  const followingPosts = await Post.find({ author: { $in: following }, isPublic: true })
    .sort({ createdAt: -1 }).limit(10).populate('author', '-password');

  const interestPosts = userInterests.length > 0
    ? await Post.find({ tags: { $in: userInterests }, author: { $nin: [...following, userId] }, isPublic: true })
        .sort({ createdAt: -1 }).limit(5).populate('author', '-password')
    : [];

  const trendingPosts = await Post.find({ isPublic: true, author: { $ne: userId } })
    .sort({ likes: -1, views: -1, createdAt: -1 })
    .skip(skip).limit(10).populate('author', '-password');

  // Merge and deduplicate
  const seen = new Set();
  const merged = [...followingPosts, ...interestPosts, ...trendingPosts].filter(p => {
    if (seen.has(p._id.toString())) return false;
    seen.add(p._id.toString());
    return true;
  });

  // AI scoring
  const scored = merged.map(post => {
    let score = 0;
    if (following.some(f => f.toString() === post.author._id.toString())) score += 100;
    const tagOverlap = post.tags.filter(t => userInterests.includes(t)).length;
    score += tagOverlap * 30;
    score += Math.min(post.likes.length * 2, 50);
    score += Math.min(post.comments.length * 3, 30);
    score += Math.min(post.views * 0.1, 20);
    const ageHours = (Date.now() - post.createdAt) / 3600000;
    score -= Math.min(ageHours * 0.5, 40);
    return { ...post.toObject(), _score: score };
  });

  return scored.sort((a, b) => b._score - a._score).slice(0, limit);
}

router.get('/', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    const feed = await getRecommendedFeed(req.user._id, user.interests || [], user.following, req.query.page);
    res.json(feed);
  } catch(e) {
    res.status(500).json({ error: e.message });
  }
});

// Suggested users to follow (AI-powered)
router.get('/suggestions', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    const suggestions = await User.find({
      _id: { $nin: [...user.following, req.user._id] },
      interests: { $in: user.interests.length > 0 ? user.interests : ['general'] }
    }).select('-password').limit(10);
    const fallback = suggestions.length < 5
      ? await User.find({ _id: { $nin: [...user.following, req.user._id, ...suggestions.map(s => s._id)] } })
          .select('-password').sort({ followers: -1 }).limit(5 - suggestions.length)
      : [];
    res.json([...suggestions, ...fallback]);
  } catch(e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
