// routes/messages.js
const router = require('express').Router();
const Message = require('../models/Message');
const { auth } = require('../middleware/auth');

router.get('/:userId', auth, async (req, res) => {
  const messages = await Message.find({
    $or: [
      { sender: req.user._id, receiver: req.params.userId },
      { sender: req.params.userId, receiver: req.user._id }
    ]
  }).sort({ createdAt: 1 }).limit(100);
  await Message.updateMany({ sender: req.params.userId, receiver: req.user._id, read: false }, { read: true });
  res.json(messages);
});

router.post('/', auth, async (req, res) => {
  const { receiverId, content } = req.body;
  const msg = await Message.create({ sender: req.user._id, receiver: receiverId, content });
  res.status(201).json(msg);
});

router.get('/conversations/list', auth, async (req, res) => {
  const messages = await Message.aggregate([
    { $match: { $or: [{ sender: req.user._id }, { receiver: req.user._id }] } },
    { $sort: { createdAt: -1 } },
    { $group: { _id: { $cond: [{ $eq: ['$sender', req.user._id] }, '$receiver', '$sender'] }, lastMessage: { $first: '$$ROOT' } } },
    { $limit: 20 }
  ]);
  res.json(messages);
});

module.exports = router;
