const router = require('express').Router();
const Post = require('../models/Post');
const { auth } = require('../middleware/auth');

router.post('/', auth, async (req, res) => {
  try {
    const { content, media, tags, category } = req.body;
    const post = await Post.create({ author: req.user._id, content, media, tags, category });
    await post.populate('author', '-password');
    res.status(201).json(post);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

router.get('/', auth, async (req, res) => {
  const { page = 1, limit = 20 } = req.query;
  const posts = await Post.find({ isPublic: true })
    .sort({ createdAt: -1 })
    .skip((page - 1) * limit)
    .limit(parseInt(limit))
    .populate('author', '-password');
  res.json(posts);
});

router.get('/:id', auth, async (req, res) => {
  const post = await Post.findByIdAndUpdate(req.params.id, { $inc: { views: 1 } }, { new: true })
    .populate('author', '-password')
    .populate('comments.user', '-password');
  if (!post) return res.status(404).json({ error: 'Post not found' });
  res.json(post);
});

router.delete('/:id', auth, async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) return res.status(404).json({ error: 'Not found' });
  if (post.author.toString() !== req.user._id.toString()) return res.status(403).json({ error: 'Forbidden' });
  await post.deleteOne();
  res.json({ success: true });
});

router.post('/:id/like', auth, async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) return res.status(404).json({ error: 'Not found' });
  const liked = post.likes.includes(req.user._id);
  if (liked) post.likes.pull(req.user._id);
  else post.likes.addToSet(req.user._id);
  await post.save();
  res.json({ liked: !liked, likesCount: post.likes.length });
});

router.post('/:id/comment', auth, async (req, res) => {
  const { content } = req.body;
  const post = await Post.findByIdAndUpdate(
    req.params.id,
    { $push: { comments: { user: req.user._id, content } } },
    { new: true }
  ).populate('comments.user', '-password');
  res.json(post.comments);
});

router.get('/user/:userId', auth, async (req, res) => {
  const posts = await Post.find({ author: req.params.userId })
    .sort({ createdAt: -1 }).limit(50)
    .populate('author', '-password');
  res.json(posts);
});

module.exports = router;
