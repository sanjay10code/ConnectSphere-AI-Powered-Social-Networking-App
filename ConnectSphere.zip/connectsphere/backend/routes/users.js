// routes/users.js
const router = require('express').Router();
const User = require('../models/User');
const { auth } = require('../middleware/auth');

router.get('/me', auth, (req, res) => res.json(req.user));

router.get('/search', auth, async (req, res) => {
  const { q } = req.query;
  const users = await User.find({ $or: [{ username: new RegExp(q, 'i') }, { displayName: new RegExp(q, 'i') }] }).select('-password').limit(20);
  res.json(users);
});

router.get('/:id', auth, async (req, res) => {
  const user = await User.findById(req.params.id).select('-password');
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(user);
});

router.put('/me', auth, async (req, res) => {
  const allowed = ['displayName', 'bio', 'avatar', 'coverImage', 'interests'];
  const updates = Object.fromEntries(Object.entries(req.body).filter(([k]) => allowed.includes(k)));
  const user = await User.findByIdAndUpdate(req.user._id, updates, { new: true }).select('-password');
  res.json(user);
});

router.post('/:id/follow', auth, async (req, res) => {
  if (req.params.id === req.user._id.toString()) return res.status(400).json({ error: 'Cannot follow yourself' });
  const target = await User.findById(req.params.id);
  if (!target) return res.status(404).json({ error: 'User not found' });
  const isFollowing = target.followers.includes(req.user._id);
  if (isFollowing) {
    await User.findByIdAndUpdate(req.params.id, { $pull: { followers: req.user._id } });
    await User.findByIdAndUpdate(req.user._id, { $pull: { following: req.params.id } });
    res.json({ following: false });
  } else {
    await User.findByIdAndUpdate(req.params.id, { $addToSet: { followers: req.user._id } });
    await User.findByIdAndUpdate(req.user._id, { $addToSet: { following: req.params.id } });
    res.json({ following: true });
  }
});

router.get('/:id/followers', auth, async (req, res) => {
  const user = await User.findById(req.params.id).populate('followers', '-password');
  res.json(user?.followers || []);
});

router.get('/:id/following', auth, async (req, res) => {
  const user = await User.findById(req.params.id).populate('following', '-password');
  res.json(user?.following || []);
});

module.exports = router;
