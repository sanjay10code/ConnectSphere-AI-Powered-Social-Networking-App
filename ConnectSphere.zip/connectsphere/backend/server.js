const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ─── DB ───────────────────────────────────────────────────────────────────────
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/connectsphere')
  .then(() => console.log('[DB] MongoDB connected'))
  .catch(() => console.warn('[DB] MongoDB unavailable — running in demo mode'));

// ─── Routes ───────────────────────────────────────────────────────────────────
app.use('/api/auth',    require('./routes/auth'));
app.use('/api/users',   require('./routes/users'));
app.use('/api/posts',   require('./routes/posts'));
app.use('/api/messages',require('./routes/messages'));
app.use('/api/feed',    require('./routes/feed'));

app.get('/api/health', (req, res) => res.json({ status: 'ok', time: Date.now() }));

// ─── Socket.IO — Live Chat ────────────────────────────────────────────────────
const onlineUsers = new Map();

io.on('connection', socket => {
  socket.on('user:online', userId => {
    onlineUsers.set(userId, socket.id);
    io.emit('users:online', Array.from(onlineUsers.keys()));
  });

  socket.on('message:send', async ({ senderId, receiverId, content }) => {
    const receiverSocket = onlineUsers.get(receiverId);
    const msg = { senderId, receiverId, content, timestamp: Date.now(), id: Math.random().toString(36).slice(2) };
    if (receiverSocket) io.to(receiverSocket).emit('message:receive', msg);
    socket.emit('message:sent', msg);
  });

  socket.on('typing:start', ({ senderId, receiverId }) => {
    const receiverSocket = onlineUsers.get(receiverId);
    if (receiverSocket) io.to(receiverSocket).emit('typing:start', { senderId });
  });

  socket.on('typing:stop', ({ senderId, receiverId }) => {
    const receiverSocket = onlineUsers.get(receiverId);
    if (receiverSocket) io.to(receiverSocket).emit('typing:stop', { senderId });
  });

  socket.on('post:like', ({ postId, userId }) => {
    io.emit('post:liked', { postId, userId });
  });

  socket.on('disconnect', () => {
    for (const [userId, sid] of onlineUsers.entries()) {
      if (sid === socket.id) { onlineUsers.delete(userId); break; }
    }
    io.emit('users:online', Array.from(onlineUsers.keys()));
  });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => console.log(`[Server] ConnectSphere running on port ${PORT}`));
